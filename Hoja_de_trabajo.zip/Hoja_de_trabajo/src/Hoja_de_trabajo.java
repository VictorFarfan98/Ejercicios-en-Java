import javax.swing.JOptionPane;
public class Hoja_de_trabajo {

    public static void main(String[] args) {
        //programa 1 
        int num1=0;
        int contador1=0;
        String cadena1="";
        do{
            contador1++;
            num1=contador1*2;
            cadena1+=num1 +"\n";
        }while(num1<20);
        JOptionPane.showMessageDialog(null, cadena1);
        //fin programa 1
        
        //programa 2
        int num2=0;
        int contador2=0;
        String cadena2="";
        do{
            contador2++;
            num2=(contador2*2)-1;
            cadena2+=num2 +"\n";
        }while(num2<19);
        JOptionPane.showMessageDialog(null, cadena2);
        //fin programa 2 
        
        //programa 3
        int num3=0;
        int contador3=0;
        String cadena3="";
        do{
            contador3++;
            num3=contador3*10;
            cadena3+=num3 +"\n";
        }while(num3<100);
        JOptionPane.showMessageDialog(null, cadena3);
        //fin programa 3 
        
        //programa 4 
        int num4=0;
        num4=Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese un numero"));
        if(num4>=100){
            JOptionPane.showMessageDialog(null,"Ingreso un numero mayor a 100");
        }else{
            if(num4>9 && num4<100){
                JOptionPane.showMessageDialog(null, "Es una decena");
            }else{
                JOptionPane.showMessageDialog(null, "Es un digito");
            }
        }
        //fin programa 4
       
        //programa 5
        int nac=0;
        int edad=0;
        String nombre="";
        nac=Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese su fecha de nacimiento"));
        nombre=JOptionPane.showInputDialog(null, "Ingrese su nombre");
        edad=2015-nac;
        if(edad>60){
            JOptionPane.showMessageDialog(null, "Usted tiene " + edad + " años y es un anciano");
        }else{
            if(edad>17){
                JOptionPane.showMessageDialog(null, "Usted tiene " + edad + " años y es un adulto");
            }else{
                if(edad>13){
                    JOptionPane.showMessageDialog(null, "Usted tiene " + edad + " años y es un adolescente");
                }else{
                    JOptionPane.showMessageDialog(null, "Usted tiene " + edad + " años y es un niño");
                }
            }
        }
       //fin pograma 5
       //programa 6
        int menu=0;
        double suma=0;
        double resta=0;
        double multi=0;
        double div=0;
        double n1=0;
        double n2=0;
        menu=Integer.parseInt(JOptionPane.showInputDialog(null, "Elija una opcion: \n 1) Suma "
                + " \n 2) Resta  \n 3) Multiplicacion  \n 4) Division  \n  5)Salir"));
        if(menu==1){
            n1=Double.parseDouble(JOptionPane.showInputDialog(null, "Ingrese un numero"));
            n2=Double.parseDouble(JOptionPane.showInputDialog(null, "Ingrese otro numero"));
            suma=n1+n2;
            JOptionPane.showMessageDialog(null, "El resultado es:" +suma );
        }
        if(menu==2){
            n1=Double.parseDouble(JOptionPane.showInputDialog(null, "Ingrese un numero"));
            n2=Double.parseDouble(JOptionPane.showInputDialog(null, "Ingrese otro numero"));
            resta=n1-n2;
            JOptionPane.showMessageDialog(null, "El resultado es:" +resta );
        }
        if(menu==3){
            n1=Double.parseDouble(JOptionPane.showInputDialog(null, "Ingrese un numero"));
            n2=Double.parseDouble(JOptionPane.showInputDialog(null, "Ingrese otro numero"));
            multi=n1*n2;
            JOptionPane.showMessageDialog(null, "El resultado es:" +multi );
        }
        if(menu==4){
            n1=Double.parseDouble(JOptionPane.showInputDialog(null, "Ingrese un numero"));
            n2=Double.parseDouble(JOptionPane.showInputDialog(null, "Ingrese otro numero"));
            div=n1/n2;
            JOptionPane.showMessageDialog(null, "El resultado es:" + div );
        }
        if(menu==5){
            System.exit(menu);
        }
    }       
}


